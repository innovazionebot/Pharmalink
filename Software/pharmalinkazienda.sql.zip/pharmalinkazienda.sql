-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 14, 2022 alle 16:58
-- Versione del server: 10.4.24-MariaDB
-- Versione PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmalinkazienda`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `contratto`
--

CREATE TABLE `contratto` (
  `idContratto` int(11) NOT NULL,
  `idUtente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `contratto`
--

INSERT INTO `contratto` (`idContratto`, `idUtente`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `farmaco`
--

CREATE TABLE `farmaco` (
  `idFarmaco` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `principio` varchar(30) NOT NULL,
  `scadenza` date NOT NULL,
  `quantita` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `farmaco`
--

INSERT INTO `farmaco` (`idFarmaco`, `nome`, `principio`, `scadenza`, `quantita`) VALUES
(1, 'Tachipirina', 'Prova', '2022-05-16', 60),
(2, 'Oki', 'Prova', '2022-06-05', 140);

-- --------------------------------------------------------

--
-- Struttura della tabella `farmacocontratto`
--

CREATE TABLE `farmacocontratto` (
  `idContratto` int(11) NOT NULL,
  `idFarmaco` int(11) NOT NULL,
  `quantita` int(11) NOT NULL,
  `periodo` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `farmacoordine`
--

CREATE TABLE `farmacoordine` (
  `idOrdine` int(11) NOT NULL,
  `idFarmaco` int(11) NOT NULL,
  `quantita` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `farmacoordine`
--

INSERT INTO `farmacoordine` (`idOrdine`, `idFarmaco`, `quantita`, `id`) VALUES
(10, 1, 20, 16),
(10, 2, 30, 17),
(11, 1, 20, 18),
(11, 2, 30, 19);

-- --------------------------------------------------------

--
-- Struttura della tabella `ordine`
--

CREATE TABLE `ordine` (
  `idOrdine` int(11) NOT NULL,
  `idUtente` int(11) NOT NULL,
  `dataConsegna` date NOT NULL,
  `stato` varchar(30) NOT NULL,
  `note` varchar(30) NOT NULL,
  `dataOrdine` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `ordine`
--

INSERT INTO `ordine` (`idOrdine`, `idUtente`, `dataConsegna`, `stato`, `note`, `dataOrdine`) VALUES
(10, 3, '2022-06-21', 'In preparazione', 'NULL', '2022-06-14 16:54:57'),
(11, 3, '2022-06-21', 'In preparazione', 'NULL', '2022-06-14 16:55:37');

-- --------------------------------------------------------

--
-- Struttura della tabella `utente`
--

CREATE TABLE `utente` (
  `nome` varchar(30) NOT NULL,
  `cognome` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `lavoro` varchar(30) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utente`
--

INSERT INTO `utente` (`nome`, `cognome`, `email`, `password`, `lavoro`, `id`) VALUES
('Salvatore', 'Vigano\'', 'salvatore.vigano06@gmail.com', 'prova', 'farmacista', 1),
('Francesco Paolo', 'Rosone', 'cicciopaoloros@gmail.com', 'prova', 'farmacista', 2),
('a', 'a', 'a', 'a', 'farmacista', 3);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `contratto`
--
ALTER TABLE `contratto`
  ADD PRIMARY KEY (`idContratto`),
  ADD KEY `idUtente` (`idUtente`);

--
-- Indici per le tabelle `farmaco`
--
ALTER TABLE `farmaco`
  ADD PRIMARY KEY (`idFarmaco`);

--
-- Indici per le tabelle `farmacocontratto`
--
ALTER TABLE `farmacocontratto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idContratto` (`idContratto`),
  ADD KEY `idFarmaco` (`idFarmaco`);

--
-- Indici per le tabelle `farmacoordine`
--
ALTER TABLE `farmacoordine`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idOrdine` (`idOrdine`),
  ADD KEY `idFarmaco` (`idFarmaco`);

--
-- Indici per le tabelle `ordine`
--
ALTER TABLE `ordine`
  ADD PRIMARY KEY (`idOrdine`),
  ADD KEY `idUtente` (`idUtente`);

--
-- Indici per le tabelle `utente`
--
ALTER TABLE `utente`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `contratto`
--
ALTER TABLE `contratto`
  MODIFY `idContratto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `farmaco`
--
ALTER TABLE `farmaco`
  MODIFY `idFarmaco` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `farmacocontratto`
--
ALTER TABLE `farmacocontratto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `farmacoordine`
--
ALTER TABLE `farmacoordine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT per la tabella `ordine`
--
ALTER TABLE `ordine`
  MODIFY `idOrdine` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT per la tabella `utente`
--
ALTER TABLE `utente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `contratto`
--
ALTER TABLE `contratto`
  ADD CONSTRAINT `contratto_ibfk_1` FOREIGN KEY (`idUtente`) REFERENCES `utente` (`id`);

--
-- Limiti per la tabella `farmacocontratto`
--
ALTER TABLE `farmacocontratto`
  ADD CONSTRAINT `farmacocontratto_ibfk_1` FOREIGN KEY (`idContratto`) REFERENCES `contratto` (`idContratto`),
  ADD CONSTRAINT `farmacocontratto_ibfk_2` FOREIGN KEY (`idFarmaco`) REFERENCES `farmaco` (`idFarmaco`);

--
-- Limiti per la tabella `farmacoordine`
--
ALTER TABLE `farmacoordine`
  ADD CONSTRAINT `farmacoordine_ibfk_1` FOREIGN KEY (`idOrdine`) REFERENCES `ordine` (`idOrdine`),
  ADD CONSTRAINT `farmacoordine_ibfk_2` FOREIGN KEY (`idFarmaco`) REFERENCES `farmaco` (`idFarmaco`);

--
-- Limiti per la tabella `ordine`
--
ALTER TABLE `ordine`
  ADD CONSTRAINT `ordine_ibfk_1` FOREIGN KEY (`idUtente`) REFERENCES `utente` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
