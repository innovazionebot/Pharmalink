package IndirizzoIP;

public class IndirizzoIP {
    public String ip;
    public IndirizzoIP(){
        this.ip = "5.tcp.eu.ngrok.io:10833";
    }
}