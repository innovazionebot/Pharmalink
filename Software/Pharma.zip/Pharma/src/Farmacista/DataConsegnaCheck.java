package Farmacista;

public class DataConsegnaCheck{
    static String dataConsegnaCheck;
    public DataConsegnaCheck(String dataConsegnaCheck){
        this.dataConsegnaCheck = dataConsegnaCheck;
    }

    public static String getDataConsegnaCheck() {
        return dataConsegnaCheck;
    }
}