package Magazziniere;

import Magazziniere.*;

public class CheckIDMagazziniere {
    static String id;
    public CheckIDMagazziniere(String a){
        id = a;
    }
    public static String getID() {
        return id;
    }
}
