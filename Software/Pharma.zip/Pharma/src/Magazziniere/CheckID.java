package Magazziniere;

import Magazziniere.*;

public class CheckID {
    static String id;
    public CheckID(String a){
        id = a;
    }
    public static String getID() {
        return id;
    }
}
