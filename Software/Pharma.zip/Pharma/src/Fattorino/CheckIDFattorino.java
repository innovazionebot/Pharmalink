package Fattorino;

public class CheckIDFattorino {
    static String id;
    public CheckIDFattorino(String a){
        id = a;
    }
    public static String getID() {
        return id;
    }
}
