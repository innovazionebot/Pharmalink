package Farmacista;

public class NumeroOrdine {
    private String numOrdine;
    public NumeroOrdine(String numOrdine){
        this.numOrdine = numOrdine;
    }
    
    public String getNumeroOrdine(){
        return numOrdine;
    }
}
