
import Login.Login;

public class Main {
    public static void main(String args[]) throws ClassNotFoundException{
        Login auth = new Login();
        auth.setVisible(true);
    }
}