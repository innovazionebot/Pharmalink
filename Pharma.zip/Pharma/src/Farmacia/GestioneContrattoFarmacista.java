package Farmacia;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.*;

public class GestioneContrattoFarmacista extends javax.swing.JFrame {
    private Connection connessione;
    public GestioneContrattoFarmacista() throws ClassNotFoundException {
        Connection connessione;
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "pharmalinkazienda";
        String driver = "com.mysql.cj.jdbc.Driver";
        String username = "root";
        String password = "";
        try{
            Class.forName(driver);
            this.connessione = DriverManager.getConnection(url+dbName, username, password);
        }
        catch (SQLException ex){
            System.out.println("Connessione non avvenuta, errore");
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menuButton = new javax.swing.JButton();
        diminuisciQuantitaButton = new javax.swing.JButton();
        modificaPeriodoButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        menuButton.setBackground(new java.awt.Color(0, 51, 255));
        menuButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        menuButton.setForeground(new java.awt.Color(255, 255, 255));
        menuButton.setText("Menù principale");
        menuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuButtonActionPerformed(evt);
            }
        });

        diminuisciQuantitaButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        diminuisciQuantitaButton.setForeground(new java.awt.Color(0, 0, 0));
        diminuisciQuantitaButton.setText("Diminuisci Quantità");
        diminuisciQuantitaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diminuisciQuantitaButtonActionPerformed(evt);
            }
        });

        modificaPeriodoButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        modificaPeriodoButton.setForeground(new java.awt.Color(0, 0, 0));
        modificaPeriodoButton.setText("Modifica Periodicità");
        modificaPeriodoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificaPeriodoButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Pharmalink - Gestione Contratto");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(menuButton)
                    .addComponent(diminuisciQuantitaButton)
                    .addComponent(modificaPeriodoButton)
                    .addComponent(jLabel1))
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(modificaPeriodoButton)
                .addGap(33, 33, 33)
                .addComponent(diminuisciQuantitaButton)
                .addGap(28, 28, 28)
                .addComponent(menuButton)
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuButtonActionPerformed
        JFrame frame;
        frame = new JFrame("Uscita");
        frame.setResizable(false);
        if (JOptionPane.showConfirmDialog(frame, "Vuoi tornare al menù principale?", "Avviso", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_NO_OPTION){
            try {
                this.toBack();
                setVisible(false);
                new Farmacista().toFront();
                new Farmacista().setState(java.awt.Frame.NORMAL);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Farmacista.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_menuButtonActionPerformed

    private void modificaPeriodoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificaPeriodoButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_modificaPeriodoButtonActionPerformed
    
    private String id;
    private void diminuisciQuantitaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diminuisciQuantitaButtonActionPerformed
        id = CheckID.getID();
        Statement pst;
        ResultSet rs;
        try{
            String query = "SELECT f.nomeFarmaco, f.principioAttivo, f.dataScadenza, f.quantitaFarmaco, u.id FROM farmaco f INNER JOIN contratto c ON c.idContratto = f.idContratto INNER JOIN utente u ON u.id = f.idUtente AND u.id='"+id+"'";
            pst = connessione.prepareStatement(query);
            rs  = pst.executeQuery(query);
            if(!rs.next()){
                JOptionPane.showMessageDialog(null,"Nessun contratto attivo o nessun farmaco disponibile.", "Errore", JOptionPane.WARNING_MESSAGE);
                pst.close();
                rs.close();
            }
            else{
                ModificaQuantita mq = new ModificaQuantita();
                mq.setVisible(true);
                String id = rs.getString("id");
                CheckID controllo = new CheckID(id);
            }
        }
        catch(HeadlessException | SQLException  e){
            Logger.getLogger(Farmacista.class.getName()).log(Level.SEVERE, null, e);
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_diminuisciQuantitaButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton diminuisciQuantitaButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton menuButton;
    private javax.swing.JButton modificaPeriodoButton;
    // End of variables declaration//GEN-END:variables
}
